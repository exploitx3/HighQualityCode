﻿namespace EmpiresMine.IO
{
    public interface IInputOutputHandler : IReader, IWriter
    {
         
    }
}