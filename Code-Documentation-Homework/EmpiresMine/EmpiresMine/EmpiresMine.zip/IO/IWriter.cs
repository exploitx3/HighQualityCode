﻿namespace EmpiresMine.IO
{
    public interface IWriter
    {
        void Write(string message);
    }
}