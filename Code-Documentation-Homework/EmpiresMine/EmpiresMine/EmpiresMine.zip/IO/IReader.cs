﻿namespace EmpiresMine.IO
{
    public interface IReader
    {
        string ReadLine();
    }
}