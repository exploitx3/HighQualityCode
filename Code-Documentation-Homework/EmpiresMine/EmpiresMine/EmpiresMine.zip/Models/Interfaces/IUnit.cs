﻿namespace EmpiresMine.Models.Interfaces
{
    public interface IUnit
    {
        int Health { get; set; }
        int AttackDamage { get; } 
    }
}