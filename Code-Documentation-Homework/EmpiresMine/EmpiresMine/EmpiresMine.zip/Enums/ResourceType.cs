﻿namespace EmpiresMine.Enums
{
    public enum ResourceType
    {
        Gold,Steel
    }
}