﻿namespace EmpiresMine.Interfaces
{
    public interface ICommandDispacher
    {
        void DispatchCommand(string[] parameters);


    }
}