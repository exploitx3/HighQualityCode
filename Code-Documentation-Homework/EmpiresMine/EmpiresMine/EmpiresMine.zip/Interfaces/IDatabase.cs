﻿using System.Collections;
using System.Collections.Generic;
using EmpiresMine.Enums;
using EmpiresMine.Models.Interfaces;

namespace EmpiresMine.Interfaces
{
    public interface IDatabase
    {
        IDictionary<ResourceType, int> Resources { get; }
        IEnumerable<IUnit> Units { get; }
        void AddUnit(IUnit unit);

        IList<IBuilding> Buildings { get; } 
    }
}