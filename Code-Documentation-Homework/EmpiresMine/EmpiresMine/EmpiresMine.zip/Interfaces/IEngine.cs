﻿namespace EmpiresMine.Interfaces
{
    public interface IEngine
    {
        IDatabase Database { get; }
        ICommandDispacher CommandDispacher { get; }

        void Run();
    }
}