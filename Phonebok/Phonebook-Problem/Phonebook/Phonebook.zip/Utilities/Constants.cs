﻿namespace Phonebook.Utilities
{
    public static class Constants
    {
        public const string CountryPhoneCode = "+359";
    }
}