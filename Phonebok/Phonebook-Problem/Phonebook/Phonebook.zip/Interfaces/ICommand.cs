﻿namespace Phonebook.Interfaces
{
    public interface ICommand
    {
        string Execute();
    }
}