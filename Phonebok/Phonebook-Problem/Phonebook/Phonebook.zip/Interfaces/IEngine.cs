﻿namespace Phonebook.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}