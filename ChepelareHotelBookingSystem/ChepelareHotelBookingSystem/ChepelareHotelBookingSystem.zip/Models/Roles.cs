﻿namespace ChepelareHotelBookingSystem.Models
{
    public enum Roles
    {
        User,
        VenueAdmin
    }
}
