﻿namespace ChepelareHotelBookingSystem.Interfaces
{
// Ever wondered about the difference between I...able and I...er? Here it is :)

    internal interface IF_cker
    {
        void F_ck(IF_ckable target);
    }
}