﻿namespace ChepelareHotelBookingSystem.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}