﻿namespace ChepelareHotelBookingSystem.Interfaces
{
    internal interface IF_ckable
    {
        void GetF_cked();
    }
}