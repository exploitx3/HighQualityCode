﻿namespace TheatreSystem.Core.Commands
{
    using System;
    using System.Linq;
    using System.Text;
    using Interfaces;

    public class PrintAllPerformancesCommand : BaseCommand
    {
        public PrintAllPerformancesCommand(string[] args, IDatabase database) : base(args, database)
        {
        }

        public override string Execute()
        {
            var performances = this.database.ListAllPerformances().ToList();
            if (performances.Any())
            {
                return String.Join(", ", performances);
            }

            return "No performances";
        }
    }
}