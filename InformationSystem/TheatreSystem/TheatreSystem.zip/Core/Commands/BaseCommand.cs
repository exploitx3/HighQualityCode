﻿namespace TheatreSystem.Core.Commands
{
    using System;
    using Interfaces;
    using Models;

    public abstract class BaseCommand : ICommand
    {
        protected string[] commandArgs;
        protected IDatabase database;
        
        protected BaseCommand(string[] args, IDatabase database)
        {
            this.commandArgs = args;
            if (database == null)
            {
                throw new ArgumentNullException(nameof(database), "Database must be inicialized.");
            }
            this.database = database;
        }

        public abstract string Execute();
    }
}