﻿namespace TheatreSystem.Core.Commands
{
    using System.Linq;
    using Interfaces;

    public class PrintPerformancesCommand : BaseCommand
    {
        public PrintPerformancesCommand(string[] args, IDatabase database) : base(args, database)
        {
        }

        public override string Execute()
        {
            string theatre = this.commandArgs[0];
            var performances = this.database.ListPerformances(theatre)
                .Select(performance =>{
                    string dateTime = performance.DateTime.ToString("dd.MM.yyyy HH:mm");

                    return $"({performance.PerformanceName}, {dateTime})";
                })
                .ToList();

            string commandResult;
            if (performances.Any())
            {
                commandResult = string.Join(", ", performances);
            }
            else
            {
                commandResult = "No performances";
            }

            return commandResult;
        }
    }
}