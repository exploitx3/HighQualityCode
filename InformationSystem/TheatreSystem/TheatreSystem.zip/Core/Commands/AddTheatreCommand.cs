﻿namespace TheatreSystem.Core.Commands
{
    using Interfaces;

    public class AddTheatreCommand : BaseCommand
    {
        public AddTheatreCommand(string[] args, IDatabase database) : base(args, database)
        {
        }

        public override string Execute()
        {
            string theatreName = this.commandArgs[0];
            this.database.AddTheatre(theatreName);
            return "Theatre added";
        }
    }
}