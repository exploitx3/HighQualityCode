﻿namespace TheatreSystem.Core.Commands
{
    using System;
    using System.Globalization;
    using Interfaces;

    public class AddPerformanceCommand : BaseCommand
    {
        public AddPerformanceCommand(string[] args, IDatabase database) : base(args, database)
        {
        }

        public override string Execute()
        {
            string theatreName = this.commandArgs[0];
            string performanceTitle = this.commandArgs[1];
            DateTime dateTime = DateTime.ParseExact(this.commandArgs[2], "dd.MM.yyyy HH:mm", CultureInfo.InvariantCulture);
            TimeSpan duration = TimeSpan.Parse(this.commandArgs[3]);
            decimal price = decimal.Parse(this.commandArgs[4], CultureInfo.CurrentCulture);

            this.database.AddPerformance(theatreName, performanceTitle, dateTime, duration, price);

            string commandResult = "Performance added";
            return commandResult;
        }
    }
}