﻿namespace TheatreSystem.Core.Commands
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Interfaces;

    public class PrintAllTheatersCommand : BaseCommand
    {
        public PrintAllTheatersCommand(string[] args, IDatabase database) : base(args, database)
        {

        }

        public override string Execute()
        {
            var theatresCount = this.database.ListTheatres().Count();

            if (theatresCount > 0)
            {
                return String.Join(", ", this.database.ListTheatres());
            }
            else
            {
                return "No theatres";
            }
        }
    }
}