﻿namespace TheatreSystem.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}