﻿namespace TheatreSystem.Interfaces
{
    public interface ICommand
    {
        string Execute();
    }
}