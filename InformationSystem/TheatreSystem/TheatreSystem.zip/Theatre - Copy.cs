﻿///*//////////////////////////////////////
/////                                  ///
/////   Author: Huy Phuong Nguyen,     ///
/////   Qui Nhơn, Bình Định, Vietnam   ///
/////   Email: huy_p_n@yahoo.vn        ///
/////                                  ///
////////////////////////////////////////*/
//
//namespace TheatreSystem
//{
//    using System;
//    using Exceptions;
//    using System.Collections.Generic;
//    using Interfaces;
//   
//    public class Performance : IComparable<Performance>
//    {
//        public Performance(string theatreName, string performanceName, DateTime dateTime, TimeSpan duration, decimal price)
//        {
//            this.TheatreName = theatreName;
//            this.PerformanceName = performanceName;
//            this.DateTime = dateTime;
//            this.Duration = duration; this.Price = price;
//        }
//
//        public string TheatreName { get; protected internal set; }
//
//        public string PerformanceName { get; private set; }
//
//        public DateTime DateTime { get; set; }
//
//        public TimeSpan Duration { get; private set; }
//
//        protected internal decimal Price { get; protected set; }
//
//        int IComparable<Performance>.CompareTo(Performance otherPerformance)
//        {
//            int tmp = this.DateTime.CompareTo(otherPerformance.DateTime); return tmp;
//        }
//
//        public override string ToString()
//        {
//            string result = string.Format(
//                "Performance(Tr32: {0}; Tr23: {1}; newDateTime: {2}, duration: {3}, Gia: {4})",
//                this.TheatreName,
//                this.PerformanceName,
//                this.DateTime.ToString("dd.MM.yyyy HH:mm"),
//                this.Duration.ToString("hh':'mm"),
//                this.Price.ToString("f2"));
//
//            return result;
//        }
//    }
//
//    internal class Database : IDatabase
//    {
//        private readonly SortedDictionary<string, SortedSet<Performance>> sortedDictionaryStringSortedSetPerformance =
//        new SortedDictionary<string, SortedSet<Performance>>();
//
//        public void AddTheatre(string tt)
//        {
//            if (!this.sortedDictionaryStringSortedSetPerformance.ContainsKey(tt))
//            {
//                throw new DuplicateTheatreException("Duplicate theatre");
//            }
//
//            this.sortedDictionaryStringSortedSetPerformance[tt] = new SortedSet<Performance>();
//        }
//
//   
//
//        public IEnumerable<string> ListTheatres()
//        {
//            var sortedListOfTheatres = this.sortedDictionaryStringSortedSetPerformance.Keys;
//            return sortedListOfTheatres;
//        }
//
//        void IDatabase.AddPerformance(string theatreName,
//            string performanceName, DateTime dateTime, TimeSpan duration, decimal price)
//        {
//            if (!this.sortedDictionaryStringSortedSetPerformance.ContainsKey(theatreName))
//            {
//                throw new TheatreNotFoundException("Theatre does not exist");
//            }
//
//            var sortedSetPerformances = this.sortedDictionaryStringSortedSetPerformance[theatreName];
//
//            var performanceEndTime = dateTime + duration;
//
//            if (CheckForIncorrectDuration(sortedSetPerformances, dateTime, performanceEndTime))
//            {
//                throw new TimeDurationOverlapException("Time/duration overlap");
//            }
//
//            var newPerformance = new Performance(theatreName, performanceName, dateTime, duration, price);
//            sortedSetPerformances.Add(newPerformance);
//        }
//
//        public IEnumerable<Performance> ListAllPerformances()
//        {
//            var theatres = this.sortedDictionaryStringSortedSetPerformance.Keys;
//
//            var allPerformances = new List<Performance>();
//
//            foreach (var theatre in theatres)
//            {
//                var performances = this.sortedDictionaryStringSortedSetPerformance[theatre];
//                allPerformances.AddRange(performances);
//            }
//
//            return allPerformances;
//        }
//
//        IEnumerable<Performance> IDatabase.ListPerformances(string theatreName)
//        {
//            if (!this.sortedDictionaryStringSortedSetPerformance.ContainsKey(theatreName))
//            {
//                throw new TheatreNotFoundException("Theatre does not exist");
//            }
//            var asfd = this.sortedDictionaryStringSortedSetPerformance[theatreName];
//            return asfd;
//        }
//
//        protected internal static bool CheckForIncorrectDuration(IEnumerable<Performance> performances, DateTime newDateTime, DateTime newEndTime)
//        {
//            foreach (var performance in performances)
//            {
//                var performanceStartTime = performance.DateTime;
//                var performanceEndTime = performanceStartTime + performance.Duration;
//
//                var checkForIncorrectDuration =
//                    (performanceStartTime <= newDateTime && newDateTime <= performanceEndTime) ||
//                    (performanceStartTime <= newEndTime && newEndTime <= performanceEndTime) ||
//                    (newDateTime <= performanceStartTime && performanceStartTime <= newEndTime) ||
//                    (newDateTime <= performanceEndTime && performanceEndTime <= newEndTime);
//
//                if (checkForIncorrectDuration)
//                {
//                    return true;
//                }
//            }
//
//            return false;
//        }
//    }
//}
