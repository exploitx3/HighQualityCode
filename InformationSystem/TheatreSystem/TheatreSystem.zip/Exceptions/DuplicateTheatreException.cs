﻿namespace TheatreSystem.Exceptions
{
    using System;

    class DuplicateTheatreException : Exception
    {
        public DuplicateTheatreException(string msg)
        : base(msg)
        {
        }
    }
}