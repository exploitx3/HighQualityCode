﻿using System;

namespace TheatreSystem.Exceptions
{
    internal class TheatreNotFoundException : Exception
    {
        public TheatreNotFoundException(string msg)
            : base(msg)
        {
        }
    }
}