﻿namespace TheatreSystem
{
    using Core;
    using Interfaces;
    using Models;

    class TheatreMain
    {
        static void Main(string[] args)
        {
            IDatabase database = new Database();
            ICommandExecutor commandExecutor = new CommandExecutor(database);
            IEngine engine = new TheatreEngine(commandExecutor);

            engine.Run();
        }
    }
}