﻿namespace BangaloreUniversityLearningSystem.Enum
{
    public enum Role
    {
        Student,
        Lecturer
    }
}