﻿namespace BangaloreUniversityLearningSystem.Data
{
    using System.Collections.Generic;
    using Models;

    public class CoursesRepository : Repository<Course>
    {
        public CoursesRepository()
        {
        }
    }
}