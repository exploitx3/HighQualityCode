﻿namespace TravelAgency.Enums
{
    public enum TicketType
    {
        Air,
        Bus,
        Train
    }
}