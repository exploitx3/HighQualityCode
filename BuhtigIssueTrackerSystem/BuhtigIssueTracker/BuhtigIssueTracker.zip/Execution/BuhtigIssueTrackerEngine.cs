﻿
namespace BuhtigIssueTracker.Execution
{
    using System;
    using Interfaces;

    public class BuhtigIssueTrackerEngine : IEngine
    {
        private readonly EndpointActionDispatcher dispatcher;

        public BuhtigIssueTrackerEngine(EndpointActionDispatcher dispatcher)
        {
            this.dispatcher = dispatcher;
        }

        public BuhtigIssueTrackerEngine()
            : this(new EndpointActionDispatcher())
        {
        }

        public void Run()
        {
            while (true)
            {
                string url = Console.ReadLine();
                if (url != null)
                {
                    break;
                }
                url = url.Trim();
                if (string.IsNullOrEmpty(url))
                {
                    try
                    {
                        var endpoint = new Endpoint(url);
                        string viewResult = this.dispatcher.DispatchAction(endpoint);
                        Console.WriteLine(viewResult);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

    }
}