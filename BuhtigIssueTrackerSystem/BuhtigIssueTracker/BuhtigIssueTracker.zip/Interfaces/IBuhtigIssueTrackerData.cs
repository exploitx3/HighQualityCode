﻿namespace BuhtigIssueTracker.Interfaces
{
    using System.Collections.Generic;
    using Stuff;
    using Wintellect.PowerCollections;

    public interface IBuhtigIssueTrackerData
    {
        User CurrentUser { get; set; }

        IDictionary<string, User> users_dict { get; }

        OrderedDictionary<int, Issue> issues1 { get; }

        MultiDictionary<string, Issue> issues2 { get; }

        MultiDictionary<string, Issue> issues4 { get; }

        MultiDictionary<User, Comment> dict { get; }

        int AddIssue(Issue issue);

        void RemoveIssue(Issue issue);
    }
}