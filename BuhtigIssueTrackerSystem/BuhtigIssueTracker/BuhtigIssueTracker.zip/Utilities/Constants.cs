﻿namespace BuhtigIssueTracker.Utilities
{
    public class Constants
    {
         
    }
}