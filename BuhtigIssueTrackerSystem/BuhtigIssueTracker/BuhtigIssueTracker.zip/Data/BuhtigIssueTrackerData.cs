﻿namespace BuhtigIssueTracker.Data
{
    using System.Collections.Generic;
    using Interfaces;
    using Stuff;
    using Wintellect.PowerCollections;

    public class BuhtigIssueTrackerData : IBuhtigIssueTrackerData
    {
        private int nextIssueId;

        public BuhtigIssueTrackerData()
        {
            this.nextIssueId = 1;
            this.users_dict = new Dictionary<string, User>();
                
            this.issues = new MultiDictionary<Issue, string>(true);
            this.issues1 = new OrderedDictionary<int, Issue>();
            this.issues2 = new MultiDictionary<string, Issue>(true);
            this.issues3 = new MultiDictionary<string, Issue>(true);
                
            this.dict = new MultiDictionary<User, Comment>(true);
            // TODO: Check if this is necessary
            this.kommentaren = new Dictionary<Comment, User>();
        }

        public User CurrentUser { get; set; }

        public IDictionary<string, User> users_dict { get; set; }

        OrderedDictionary<int, Issue> IBuhtigIssueTrackerData.issues1 { get; }

        MultiDictionary<string, Issue> IBuhtigIssueTrackerData.issues2 { get; }

        MultiDictionary<string, Issue> IBuhtigIssueTrackerData.issues4 { get; }

        MultiDictionary<User, Comment> IBuhtigIssueTrackerData.dict { get; }

        public MultiDictionary<Issue, string> issues { get; set; }

        IDictionary<string, User> IBuhtigIssueTrackerData.users_dict { get; }

        public OrderedDictionary<int, Issue> issues1 { get; set; }

        public MultiDictionary<string, Issue> issues2 { get; set; }

        public MultiDictionary<string, Issue> issues3 { get; set; }

        public MultiDictionary<string, Issue> issues4 { get; set; }

        public MultiDictionary<User, Comment> dict { get; set; }

        public Dictionary<Comment, User> kommentaren { get; set; }

        public int AddIssue(Issue issue)
        {
            //TODO: Extract issue creation logic here
            return 0;
        }

        public void RemoveIssue(Issue p)
        {
            //TODO: Extract issue deletion logic here
            return;
        }
    }
}