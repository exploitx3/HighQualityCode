﻿namespace BuhtigIssueTracker.Utilities
{
    public class Constants
    {
        public const int MinCommentTextLength = 2;

        public const int MinIssueTitleLength = 3;

        public const int MinIssueDescriptionLength = 5;

    }
}